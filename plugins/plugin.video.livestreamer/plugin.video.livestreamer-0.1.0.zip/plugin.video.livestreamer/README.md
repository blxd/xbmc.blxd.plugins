# plugin.video.livestreamer
A wrapper around the python library livestreamer for playing videos supported by the livestreamer module.

- Author: blxd
- Version: 0.1.0
- Github: https://github.com/blxd/plugin.video.livestreamer

## Download and Installation

- This is a support plugin and provides no user interface other than configuration.
- Simply download [plugin.video.livestreamer-0.1.0.zip](https://github.com/blxd/plugin.video.livestreamer/releases/download/v0.1.0/plugin.video.livestreamer-0.1.0.zip) file and install it in Kodi, you will also need the script.module.xbmcswift2 addon.
- Or install my [repo add-on](https://github.com/blxd/repository.blxd.plugins) and then install the livestreamer add-on from there.
